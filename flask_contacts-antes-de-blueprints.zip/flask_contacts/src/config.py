import os

DEBUG = True
PUERTO = 3000
secret_key = 'A0Zr98j/3yX R~XHH!jmN]LWX/,?RT'
SQLALCHEMY_DATABASE_URI = 'mysql://root:@localhost/pythonflaskcontactos'
SQLALCHEMY_TRACK_MODIFICATIONS = False
